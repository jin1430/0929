package com.example.GoCafe.domain;
public enum NotificationType {
    REVIEW, CAFE_APPROVED, CAFE_REJECTED
}
