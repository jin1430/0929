/* =========================================
   CafeGo – Global UI & Auth (CSP-safe)
   ========================================= */

(() => {
  "use strict";

  /* ---------- Token helpers ---------- */
  function setToken(token){
    if(!token){ localStorage.removeItem('cafego_token'); return; }
    localStorage.setItem('cafego_token', token);
  }
  function getToken(){ return localStorage.getItem('cafego_token') || null; }
  function getAuthHeaders(){ const t=getToken(); return t?{Authorization:`Bearer ${t}`}:{ }; }

  /* ---------- Header elements ---------- */
  const loginFormHeader = document.getElementById('loginFormHeader');
  const logoutBtnHeader = document.getElementById('logoutBtnHeader');
  const meEmailHeader   = document.getElementById('meEmailHeader');
  const authOut         = document.querySelector('.cg-auth-out');
  const authIn          = document.querySelector('.cg-auth-in');

  // (본문에 과거 폼이 남아있어도 안전하게)
  const loginFormBody   = document.getElementById('loginForm');
  const logoutBtnBody   = document.getElementById('logoutBtn');
  const meBoxBody       = document.getElementById('meBox');
  const meEmailBody     = document.getElementById('meEmail');

  /* ---------- Me fetch / toggle ---------- */
  async function fetchMe(){
    try{
      const res = await fetch('/api/auth/me', { headers:{ ...getAuthHeaders() }});
      if(res.ok){
        const me = await res.json();
        if(meEmailHeader) meEmailHeader.textContent = me.memberEmail || '';
        if(authOut) authOut.style.display='none';
        if(authIn)  authIn.hidden=false;
        if(meBoxBody) meBoxBody.hidden=false;
        if(meEmailBody) meEmailBody.textContent = me.memberEmail || '';
      }else{
        if(authOut) authOut.style.display='';
        if(authIn)  authIn.hidden=true;
        if(meBoxBody) meBoxBody.hidden=true;
      }
    }catch(_){
      if(authOut) authOut.style.display='';
      if(authIn)  authIn.hidden=true;
      if(meBoxBody) meBoxBody.hidden=true;
    }
  }

  /* ---------- Login (header/body) ---------- */
  async function handleLogin(form){
    const fd = new FormData(form);
    const payload = { memberEmail: fd.get('memberEmail'), memberPassword: fd.get('memberPassword') };
    const res = await fetch('/api/auth/login', {
      method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify(payload)
    });
    if(res.ok){
      const data = await res.json(); // {tokenType:"Bearer", token:"..."}
      setToken(data.token);
      await fetchMe();
      const details = form.closest('details'); if(details) details.open=false;
      // 로그인 후 현재 페이지 유지
      return;
    }else{
      const err = await res.json().catch(()=>({message:'로그인 실패'}));
      alert(err.message || '로그인 실패');
    }
  }
  if(loginFormHeader){ loginFormHeader.addEventListener('submit', e=>{ e.preventDefault(); handleLogin(loginFormHeader); }); }
  if(loginFormBody){   loginFormBody.addEventListener('submit',   e=>{ e.preventDefault(); handleLogin(loginFormBody);   }); }

  /* ---------- Logout ---------- */
  async function handleLogout(){
    try{ await fetch('/api/auth/logout', { method:'POST', headers:{...getAuthHeaders()} }); }catch(_){}
    setToken(null);
    await fetchMe();
  }
  if(logoutBtnHeader){ logoutBtnHeader.addEventListener('click', handleLogout); }
  if(logoutBtnBody){   logoutBtnBody.addEventListener('click',   handleLogout); }

  /* ---------- Chips -> /search ---------- */
  document.querySelectorAll('.cg-chip').forEach(chip=>{
    chip.addEventListener('click', ()=>{
      const tag = chip.dataset.tag, cat = chip.dataset.category;
      const url = new URL(location.origin + '/search');
      if(tag) url.searchParams.set('tag', tag);
      if(cat) url.searchParams.set('category', cat);
      location.href = url.toString();
    });
  });

  /* ---------- data-confirm 공통 확인 ---------- */
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-confirm]');
    if (el) {
      const msg = el.getAttribute('data-confirm') || '진행할까요?';
      if (!window.confirm(msg)) {
        e.preventDefault();
        e.stopPropagation();
      }
    }
  });

  /* ---------- 이미지 onerror 대체(폴백) ---------- */
  const hideOnError = (img) => {
    img.style.display = 'none';
    const wrap = img.parentElement;
    if (wrap) wrap.classList.add('cg-noimg');
  };
  document.querySelectorAll('img.cg-card__img, img.cg-feed__photo').forEach(img => {
    img.addEventListener('error', () => hideOnError(img));
  });

  // ===== 리뷰 모달 =====
  document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('reviewModal');
    if (!modal) return;

    const form = modal.querySelector('form');
    const cafeIdInput = document.getElementById('modalCafeId');
    const mainEl = document.querySelector('main.cg-container');
    const CLOSE_SELECTOR = '[data-close-modal], .cg-modal__backdrop';
    let lastClickedCafeId = '';
    let lastFocused = null;
    let bodyTabIndexBackup = null;

    const lock   = () => document.body.classList.add('cg-modal-open');
    const unlock = () => document.body.classList.remove('cg-modal-open');

    const cafeIdFromMain = () => mainEl ? (mainEl.getAttribute('data-cafe-id') || '') : '';
    const cafeIdFromPath = () => {
      const m = location.pathname.match(/\/cafes\/(\d+)/);
      return m ? m[1] : '';
    };
    function ensureCafeId(clickedId) {
      if (!cafeIdInput) return;
      if (cafeIdInput.value && cafeIdInput.value.trim() !== '') return;
      cafeIdInput.value = (clickedId || '').trim() || cafeIdFromMain() || cafeIdFromPath();
    }

    function focusBodySafely() {
      // body를 임시로 포커스 가능하게 만들고 포커스 이동
      bodyTabIndexBackup = document.body.getAttribute('tabindex');
      document.body.setAttribute('tabindex', '-1');
      try { document.body.focus({ preventScroll: true }); } catch (_) {}
    }
    function restoreBodyTabIndex() {
      if (bodyTabIndexBackup === null) document.body.removeAttribute('tabindex');
      else document.body.setAttribute('tabindex', bodyTabIndexBackup);
      bodyTabIndexBackup = null;
    }

    function reallyOpen() {
      modal.removeAttribute('inert');
      modal.setAttribute('aria-hidden', 'false');
      modal.classList.add('is-open');
      lock();
      // 포커스 관리
      lastFocused = document.activeElement;
      const first = modal.querySelector('textarea, input, select, button, a[href]');
      if (first) first.focus({ preventScroll: true });
    }

    function reallyClose() {
      // 1) 모달 내부 포커스 해제 & 바깥으로 이동
      if (modal.contains(document.activeElement)) {
        try { document.activeElement.blur(); } catch (_) {}
      }
      // 우선 body로 포커스 이동(경고 방지)
      focusBodySafely();

      // 2) 다음 animation frame에서 aria-hidden/inert 적용
      requestAnimationFrame(() => {
        modal.setAttribute('aria-hidden', 'true');
        modal.setAttribute('inert', '');
        modal.classList.remove('is-open');
        unlock();

        // 3) 포커스 원래 위치 복원(가능하면)
        if (lastFocused && document.contains(lastFocused)) {
          try { lastFocused.focus({ preventScroll: true }); } catch (_) {}
        }
        restoreBodyTabIndex();
      });
    }

    function openModal(clickedId) {
      lastClickedCafeId = clickedId || lastClickedCafeId || '';
      ensureCafeId(lastClickedCafeId);
      if (location.hash !== '#reviewModal') location.hash = 'reviewModal'; // :target 폴백과 동기화
      requestAnimationFrame(reallyOpen); // 해시 변경 직후 타이밍 보정
    }

    function closeModal() {
      reallyClose();
      try { history.replaceState(null, document.title, location.pathname + location.search); } catch (_) {}
      if (location.hash) location.hash = '';
    }

    // 열기 버튼 (위임)
    document.addEventListener('click', (e) => {
      const openBtn = e.target.closest('a[data-review-modal]');
      if (openBtn) {
        e.preventDefault();
        openModal(openBtn.getAttribute('data-cafe-id') || '');
      }
    });

    // 닫기: 버튼/배경 + 시트 바깥 클릭
    document.addEventListener('click', (e) => {
      if (modal.getAttribute('aria-hidden') === 'false') {
        const closeTarget = e.target.closest(CLOSE_SELECTOR);
        if (closeTarget) {
          e.preventDefault();
          closeModal();
          return;
        }
        const insideSheet = e.target.closest('.cg-modal__sheet');
        if (!insideSheet && modal.contains(e.target)) {
          e.preventDefault();
          closeModal();
        }
      }
    });

    // ESC 닫기
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') {
        e.preventDefault();
        closeModal();
      }
    });

    // 해시 직접 접근/뒤로가기
    function syncOnHash() {
      if (location.hash === '#reviewModal') {
        ensureCafeId(lastClickedCafeId);
        reallyOpen();
      } else {
        reallyClose();
      }
    }
    window.addEventListener('hashchange', syncOnHash);
    syncOnHash();

    // ?review=open 쿼리 처리
    if (new URLSearchParams(location.search).get('review') === 'open' && location.hash !== '#reviewModal') {
      openModal();
    }

    // 제출 가드
    if (form) {
      form.addEventListener('submit', (e) => {
        ensureCafeId(lastClickedCafeId);
        if (!cafeIdInput || !cafeIdInput.value) {
          e.preventDefault();
          alert('카페 정보가 유실되어 리뷰를 저장할 수 없어요. 새로고침 후 다시 시도해주세요.');
          return;
        }
        const fileInput = document.getElementById('photoInput');
        if (fileInput && fileInput.files) {
          if (fileInput.files.length > 5) {
            e.preventDefault();
            alert('사진은 최대 5장까지 업로드할 수 있어요.');
            return;
          }
          for (const f of fileInput.files) {
            if (f.size > 10 * 1024 * 1024) {
              e.preventDefault();
              alert('사진 용량은 파일당 10MB 이하로 업로드해주세요.');
              return;
            }
          }
        }
      });
    }
  });


  /* ---------- Auth 페이지 독립 폼 (login/signup 템플릿) ---------- */
  const loginPageForm  = document.getElementById('loginPageForm');
  const signupPageForm = document.getElementById('signupPageForm');

  if (loginPageForm){
    loginPageForm.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const fd = new FormData(loginPageForm);
      const payload = { memberEmail: fd.get('memberEmail'), memberPassword: fd.get('memberPassword') };
      const res = await fetch('/api/auth/login', {
        method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)
      });
      if(res.ok){
        // 서버가 HttpOnly 쿠키도 내려줄 수 있으므로 새로고침
        location.href = '/';
      }else{
        const err = await res.json().catch(()=>({message:'로그인 실패'}));
        alert(err.message || '로그인 실패');
      }
    });
  }

  if (signupPageForm){
    signupPageForm.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const fd  = new FormData(signupPageForm);
      const pw  = fd.get('memberPassword');
      const pw2 = fd.get('memberPasswordConfirm');
      if(pw !== pw2){
        alert('비밀번호가 일치하지 않습니다.');
        return;
      }
      const payload = { memberEmail: fd.get('memberEmail'), memberPassword: pw };
      const res = await fetch('/api/auth/signup', {
        method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)
      });
      if(res.ok){
        alert('회원가입이 완료되었습니다. 로그인해 주세요.');
        location.href = '/login';
      }else{
        const err = await res.json().catch(()=>({message:'회원가입 실패'}));
        alert(err.message || '회원가입 실패');
      }
    });
  }

  /* ---------- 초기화 ---------- */
  fetchMe();

})();
