-- FK 잠시 비활성화
SET REFERENTIAL_INTEGRITY FALSE;

-- 깔끔 초기화
DELETE FROM cafe_tag;
DELETE FROM cafe;
DELETE FROM member;
DELETE FROM cafe_photo;
DELETE FROM cafe_tag;

-- 아이디 시퀀스 리셋 (없으면 무시됨)
ALTER TABLE cafe      ALTER COLUMN cafe_id RESTART WITH 1;
ALTER TABLE cafe_tag  ALTER COLUMN cafe_tag_id RESTART WITH 1;
ALTER TABLE member    ALTER COLUMN member_id RESTART WITH 1;
ALTER TABLE cafe_photo ALTER COLUMN cafe_photo_id RESTART WITH 1;
ALTER TABLE cafe_tag ALTER COLUMN cafe_tag_id RESTART WITH 1;

-- Cafe
INSERT INTO cafe
  (cafe_id, owner_id, name, address, lat, lon, number, date, views, code, status, biz_doc)
VALUES
  (1, 1, '카페무드 홍대점','서울 마포구 양화로 45', 37.5569, 126.9238, '000000000000', CURRENT_TIMESTAMP, 432, 'CAFE000001', 'APPROVED', NULL),
  (2, 2, '브런치랩 합정',  '서울 마포구 독막로 15', 37.5498, 126.9136, '000000000001', CURRENT_TIMESTAMP, 210, 'CAFE000002', 'APPROVED', NULL),
  (3, 3, '라떼가좋아',    '서울 마포구 잔다리로 20', 37.5531, 126.9204, '000000000002', CURRENT_TIMESTAMP, 987, 'CAFE000003', 'APPROVED', NULL),
  (4, 4, '루프탑뷰',      '서울 마포구 와우산로 80', 37.5539, 126.9352, '000000000003', CURRENT_TIMESTAMP, 120, 'CAFE000004', 'APPROVED', NULL),
  (5, 5, '스페셜티랩',    '서울 마포구 잔다리로 5',  37.5522, 126.9190, '000000000004', CURRENT_TIMESTAMP,  75, 'CAFE000005', 'APPROVED', NULL);


-- CafePhoto
INSERT INTO cafe_photo
  (cafe_photo_id, cafe_id, url, sort_index, is_main)
VALUES
  (1, 1, '/uploads/cafe_photos/카페무드 홍대점_00.jpg', 0, TRUE),
  (2, 1, '/uploads/cafe_photos/카페무드 홍대점_01.jpg', 1, FALSE),
  (3, 2, '/uploads/cafe_photos/브런치랩 합정_00.jpg',    0, TRUE),
  (4, 2, '/uploads/cafe_photos/브런치랩 합정_01.jpg',    1, FALSE),
  (5, 3, '/uploads/cafe_photos/라떼가좋아_00.jpg',        0, TRUE),
  (6, 4, '/uploads/cafe_photos/루프탑뷰_00.jpg',          0, TRUE),
  (7, 5, '/uploads/cafe_photos/스페셜티랩_00.jpg',        0, TRUE);


-- CafeTag
-- category_code 예: MOOD / MENU / FEATURE ...
INSERT INTO cafe_tag
  (cafe_tag_id, cafe_id, category_code, code)
VALUES
  (1,1,'MOOD','감성'), (2,1,'MENU','브런치'), (3,1,'FEATURE','콘센트많음'),
  (4,2,'MENU','브런치'), (5,2,'MOOD','데이트'), (6,2,'FEATURE','애견동반'),
  (7,3,'MENU','라떼'), (8,3,'MOOD','조용한'), (9,3,'FEATURE','와이파이빠름'),
  (10,4,'MOOD','루프탑'), (11,4,'VIEW','야경좋음'),
  (12,5,'BEAN','스페셜티'), (13,5,'BREW','핸드드립');


-- ===== Member 더미(로그인 테스트) =====
-- 비밀번호는 1234 (AuthController가 dev 편의상 평문 비교 1회 허용)
INSERT INTO member
  (member_id, email, password, nickname, age, gender, role_kind, created_at, photo, token_version)
VALUES
(1,'test@cafego.dev', '11111111', '테스터', 25, 'M', 'ROLE_MEBMER', CURRENT_TIMESTAMP, NULL, 0),
(2,'admin@cafego.dev', '11111111', '관리자', 25, 'M', 'ROLE_ADMIN', CURRENT_TIMESTAMP, NULL, 0);

-- FK 재활성화
SET REFERENTIAL_INTEGRITY TRUE;